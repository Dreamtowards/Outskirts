package ext.ntty.pkt;

import outskirts.network.Packet;
import outskirts.network.PacketBuffer;

public class CPacketKeepAliveResp extends Packet {

    public CPacketKeepAliveResp() {}

    @Override
    public void write(PacketBuffer buf) {

    }

    @Override
    public void read(PacketBuffer buf) {

    }
}
