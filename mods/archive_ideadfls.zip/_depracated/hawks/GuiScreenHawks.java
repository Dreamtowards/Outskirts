package outskirts.client.gui.screen.hawks;

import outskirts.client.gui.Gui;
import outskirts.client.gui.screen.GuiScreen;

public class GuiScreenHawks extends GuiScreen {

    public Gui windows = addGui(new Gui());

}
