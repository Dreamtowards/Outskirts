package outskirts.client.mdl;

public class IllegalFieldException extends RuntimeException {
}
